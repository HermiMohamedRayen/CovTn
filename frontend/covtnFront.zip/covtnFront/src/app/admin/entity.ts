import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Interface pour l'entité générique
export interface Entity {
  id?: number;
  name: string;
  description: string;
  // Ajoutez d'autres propriétés de votre entité ici
}

@Injectable({
  providedIn: 'root'
})
export class EntityService {
  // Remplacez par l'URL de votre API backend
  private apiUrl = 'http://localhost:9092/api';

  constructor(private http: HttpClient) { }

  // READ - Récupérer toutes les entités
  getAll(): Observable<Entity[]> {
    return this.http.get<Entity[]>(`${this.apiUrl}/auth/users`, { responseType: 'text' as 'json' });
  }

  // READ - Récupérer une entité par ID
  getById(email: string): Observable<Entity> {
    return this.http.get<Entity>(`${this.apiUrl}/auth/users/${email}`, { responseType: 'text' as 'json' });
  }

  // CREATE - Créer une nouvelle entité
  create(entity: Entity): Observable<Entity> {
    return this.http.post<Entity>(`${this.apiUrl}/auth/addUsers`, entity);
  }

  // UPDATE - Mettre à jour une entité existante
  update(email: string, entity: Entity): Observable<Entity> {
    return this.http.put<Entity>(`${this.apiUrl}/auth/Updateusers/${email}`, entity);
  }

  // DELETE - Supprimer une entité
  delete(email: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/auth/users/${email}`);
  }
}
